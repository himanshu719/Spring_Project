package in.sp.main.urls;

public class OtherUrls 
{
	public static String IMAGE_UPLOAD_FOLDER = "src/main/resources/static/uploads";
	public static String IMAGE_UPLOAD_URL = "http://localhost:8080/uploads/";
}
